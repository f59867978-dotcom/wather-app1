<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Weather App</title>

  <!-- CSS -->
  <style>
    * {
      box-sizing: border-box;
      font-family: Arial, Helvetica, sans-serif;
    }

    body {
      margin: 0;
      min-height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      background: linear-gradient(135deg, #74ebd5, #9face6);
    }

    .weather-container {
      background: #ffffff;
      padding: 25px;
      border-radius: 12px;
      width: 320px;
      text-align: center;
      box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
    }

    h1 {
      margin-bottom: 15px;
      font-size: 22px;
    }

    .search-box {
      display: flex;
      gap: 8px;
      margin-bottom: 15px;
    }

    input {
      flex: 1;
      padding: 8px;
      border-radius: 6px;
      border: 1px solid #ccc;
      outline: none;
    }

    button {
      padding: 8px 12px;
      border: none;
      border-radius: 6px;
      background: #4a6cf7;
      color: white;
      cursor: pointer;
    }

    button:hover {
      background: #3b5be0;
    }

    .result {
      display: none;
      margin-top: 10px;
    }

    .temperature {
      font-size: 36px;
      font-weight: bold;
      margin: 10px 0;
    }

    .condition {
      font-size: 16px;
      color: #555;
    }

    .error {
      color: red;
      font-size: 14px;
      margin-top: 10px;
      display: none;
    }
  </style>
</head>
<body>

  <!-- HTML -->
  <div class="weather-container">
    <h1>Weather App</h1>

    <div class="search-box">
      <input type="text" id="locationInput" placeholder="Enter city name" />
      <button onclick="getWeather()">Search</button>
    </div>

    <div class="error" id="error"></div>

    <div class="result" id="result">
      <h2 id="cityName"></h2>
      <div class="temperature" id="temperature"></div>
      <div class="condition" id="condition"></div>
    </div>
  </div>

  <!-- JavaScript -->
  <script>
    const API_KEY = "d8cc9f6d06e74908a93192351260602";

    async function getWeather() {
      const location = document.getElementById("locationInput").value.trim();
      const errorDiv = document.getElementById("error");
      const resultDiv = document.getElementById("result");

      if (location === "") return;

      errorDiv.style.display = "none";
      resultDiv.style.display = "none";

      try {
        const response = await fetch(`https://api.weatherapi.com/v1/current.json?key=${API_KEY}&q=${location}&aqi=yes`);

        if (!response.ok) {
          throw new Error("Location not found");
        }

        const data = await response.json();

        document.getElementById("cityName").textContent = `${data.location.name}, ${data.location.country}`;
        document.getElementById("temperature").textContent = `${data.current.temp_c}°C`;
        document.getElementById("condition").textContent = data.current.condition.text;

        resultDiv.style.display = "block";
      } catch (error) {
        errorDiv.textContent = error.message;
        errorDiv.style.display = "block";
      }
    }
  </script>

</body>
</html>